globalThis.__sveltekit_dev = {
	base: location.pathname.split('/').slice(0, -1).join('/'),
	env: {
		// empty
	},
	version: "1792659469540"
};