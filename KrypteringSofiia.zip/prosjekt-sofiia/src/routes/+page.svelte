<script>
    let tekst = $state ("");
    let forskyvning = $state(3);
    let resultat = $state("");
    let melding = $state("");
    let metode = $state("Caesar");
    let nøkkel = $state("");

    function krypter(){
        melding = "";
        if(!gyldigTekst()) {
            melding = "Teksten må ha bare engelske bokstaver";
            resultat="";
            return;
        }
        if (metode==="Vigenere"&& !gyldigNøkkel()) {
            melding = "Nøkkel må bare innholdebokstaver fra A-Z"
            resultat=""
            return;
        }
        if (metode=== "Vigenere"){
            resultat = vigenereKrypter();
                return;
            }
        if (metode === "One-Time Pad") {
            nøkkel = genererNøkkel(tekst);
            resultat = oneTimePad(tekst, nøkkel, true);
                return;
            }
        let tekstResultat="";

        for(let i = 0;i < tekst.length; i++){
            let tegn = tekst[i];
            if (tegn >= "A" && tegn<= "Z"){
                let kode = tegn.charCodeAt(0);
                let nyKode = ((kode-65 + forskyvning)% 26)+65;
                tekstResultat+= String.fromCharCode(nyKode);

            } else if (tegn>= "a" && tegn <= "z"){
                let kode = tegn.charCodeAt(0);
                let nyKode = ((kode -97 +forskyvning)%26)+97;
                tekstResultat+= String.fromCharCode(nyKode);
            }else {
                tekstResultat+=tegn
            }

        }
        resultat= tekstResultat
    }
    function dekrypter(){
        melding = "";
        if(!gyldigTekst()) {
            melding = "Teksten må ha bare engelske bokstaver";
            resultat="";
            return;
        }
        if (metode==="Vigenere"&& !gyldigNøkkel()) {
            melding = "Nøkkel må bare innholdebokstaver fra A-Z"
            resultat=""
            return;
        }
        if (metode === "Vigenere"){
            resultat=vigenereDekrypter();
            return;
        }
        if (metode === "One-Time Pad") {
        if (!gyldigNøkkel()) {
            melding = "Nøkkelen må bare inneholde bokstaver fra A til Z.";
            resultat = "";
            return;
        }

        resultat = oneTimePad(tekst, nøkkel, false);
        return;
    }
        
        let tekstResultat="";

        for(let i = 0;i < tekst.length; i++){
            let tegn = tekst[i];
            if (tegn >= "A" && tegn<= "Z"){
                let kode = tegn.charCodeAt(0);
                let nyKode = ((kode-65 - forskyvning + 26)% 26)+65;
                tekstResultat+= String.fromCharCode(nyKode);

            } else if (tegn>= "a" && tegn <= "z"){
                let kode = tegn.charCodeAt(0);
                let nyKode = ((kode -97 - forskyvning+26)%26)+97;
                tekstResultat+= String.fromCharCode(nyKode);
            }else {
                tekstResultat+=tegn
            }

        }
        resultat= tekstResultat
    }
    function gyldigTekst(){
        return/^[A-Za-z ]+$/.test(tekst) && tekst.trim() !=="";
    }
    function gyldigNøkkel(){
        return/^[A-Za-z]+$/.test(nøkkel);
    }
    function vigenereKrypter(){
        let tekstResultat =""
        let nøkkelIndeks = 0;

        for (let i =0; i< tekst.length; i++){
            let tegn = tekst[i];
            if (tegn === " "){
                tekstResultat += tegn;
                continue;
            }
            let nøkkelTegn = nøkkel[nøkkelIndeks % nøkkel.length].toUpperCase();
            let forskyvningNå = nøkkelTegn.charCodeAt(0) - 65;
            let startKode = tegn >= "A" && tegn <= "Z" ? 65 : 97;
            let kode = tegn.toUpperCase().charCodeAt(0) - 65;
            let nyKode = ((kode + forskyvningNå) % 26) + startKode;

            tekstResultat += String.fromCharCode(nyKode);
            nøkkelIndeks++;
        }
        return tekstResultat;
    }
    function vigenereDekrypter(){
        let tekstResultat ="";
        let nøkkelIndeks=0;
       for (let i = 0; i < tekst.length; i++) {
            let tegn = tekst[i];

        if (tegn === " ") {
            tekstResultat += tegn;
            continue;
            }
            let nøkkelTegn=nøkkel[nøkkelIndeks % nøkkel.length].toUpperCase();
            let forskyvningNå = nøkkelTegn.charCodeAt(0)-65;

            let startKode = tegn >= "A" && tegn <= "Z" ? 65 : 97;
            let kode = tegn.toUpperCase().charCodeAt(0) - 65;
            let nyKode = ((kode - forskyvningNå + 26) % 26) + startKode;

            tekstResultat += String.fromCharCode(nyKode);
            nøkkelIndeks++;
        }
        return tekstResultat;
    }
    function genererNøkkel(tekst="") {
        let tilfeldigNøkkel="";
        for (let i = 0; i < tekst.length; i++) {
            if (tekst [i] === " ") {
                continue;
            }
            let tilfeldigTall = Math.floor(Math.random()*26);
            tilfeldigNøkkel += String.fromCharCode(tilfeldigTall+65);
        }
        return tilfeldigNøkkel;
    }
    function oneTimePad(tekst, nøkkel, kryptering) {
        let tekstResultat ="";
        let nøkkelIndeks=0;
        let antallBokstaver = tekst.replace(/ /g, "").length;

    if (nøkkel.length !== antallBokstaver) {
        melding = "Nøkkelen må ha like mange bokstaver som teksten.";
        return "";
    }
        for (let i = 0; i < tekst.length; i++){
        let tegn = tekst[i];
        if (tegn === " ") {
            tekstResultat += tegn;
            continue;
            }
        let nøkkelTegn=nøkkel[nøkkelIndeks];
        let forskyvningNå = nøkkelTegn.charCodeAt(0)-65;
        let startKode = tegn >= "A" && tegn <= "Z" ? 65 : 97;
        let kode = tegn.toUpperCase().charCodeAt(0) - 65;
        let nyKode;
            if (kryptering) {
                nyKode = ((kode + forskyvningNå) % 26) + startKode;
            } else {
                nyKode = ((kode - forskyvningNå + 26) % 26) + startKode;
            }

        tekstResultat += String.fromCharCode(nyKode);
        nøkkelIndeks++;
        }
        return tekstResultat;
    }
</script>

<h1>Ceasar-kryptering</h1>
<label>
    Velg metode:
    <select bind:value={metode}>
        <option value="Caesar">Caesar</option>
        <option value="Vigenere">Vigenere</option>
        <option value="One-Time Pad">One-Time Pad</option>
    </select>
</label>
<label>
    skriv inn tekst:
    <input bind:value={tekst}/>
</label>
{#if metode === "Caesar"}
    <label>
        forskyvning:
        <input type="number" bind:value={forskyvning}/>
    </label>    
{:else}
    <label>
        nøkkel:
        <input bind:value={nøkkel}>
        {#if metode === "One-Time Pad"}
        <p>Nøkkelen genereres automatiskved kryptering</p>
        {/if}
    </label>
{/if}
    

<button onclick={krypter}>Krypter</button>
<button onclick={dekrypter}>Dekrypter</button>
{#if melding}
<p>{melding}</p>
{/if}
<p>Resultat:{resultat}</p>
